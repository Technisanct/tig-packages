# tig-packages
Mono repo for all technisanct python packages.

To rebuild package
* python setup.py sdist bdist_wheel

Included of packages for
* S3
