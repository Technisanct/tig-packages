# tig-packages
Mono repo for all technisanct python packages.

This package includes :
* S3 Utils


To rebuild this package
* python setup.py sdist bdist_wheel


To import `tigpy` s3 package:

```
from tigpy.s3.utils import Utils
```
