import boto3


class S3Utils():
	"""
	s3 utils class
	"""

	def __init__(self, **kwargs):
		self.s3_resource = self._get_s3_resource(kwargs)
		self.s3_client = self._get_s3_client(kwargs)

	@staticmethod
	def _get_bucket_and_prefix(s3_path):
		"""
		split the s3 path to bucket and key
		@param s3_path: s3 path
		@type s3_path: string
		@return: s3 bucket and key
		@rtype: tuple
		"""
		_s3_path = s3_path.split('/')
		bucket, prefix = _s3_path[2], '/'.join(_s3_path[3:])
		return bucket, prefix

	def _get_s3_client(self, kwargs):
		"""
		to get s3 client object
		@param kwargs: list of arguments
		@type kwargs: list of dict
		@return: s3 resource object
		@rtype: botocore.client.S3 object
		"""
		s3_client = boto3.client(
			's3',
			aws_access_key_id=kwargs['aws_access_key_id'],
			aws_secret_access_key=kwargs['aws_secret_access_key'],
		)
		return s3_client

	def _get_s3_resource(self, kwargs):
		"""
		to get s3 resource
		@param kwargs: list of arguments
		@type kwargs: list of dict
		@return: s3 resource object
		@rtype: boto3.resources.factory.s3.ServiceResource object
		"""
		session = boto3.Session(
			aws_access_key_id=kwargs['aws_access_key_id'],
			aws_secret_access_key=kwargs['aws_secret_access_key'],
		)
		s3 = session.resource('s3')
		return s3

	def get_s3_data(self, path):
		"""
		to get s3 data in string format
		@param path: s3 path
		@type path: string
		@return: file content in s3
		@rtype: string
		"""
		bucket_name, key = self._get_bucket_and_prefix(path)
		content_object = self.s3_resource.Object(bucket_name, key)
		file_content = content_object.get()['Body'].read().decode('utf-8')
		return file_content

	def store_data(self, path, content):
		"""
		@param path: s3 path
		@type path: string
		@param content: content to store
		@type content: bytes
		@return: None
		@rtype: None
		"""

		bucket_name, key = self._get_bucket_and_prefix(path)
		s3object = self.s3_resource.Object(bucket_name, key)
		s3object.put(
			Body=content,
			ServerSideEncryption='AES256',
		)

	def move_data(self, source_path, destination_path):
		"""
		move data from one location to other
		@param source_path: source s3 path
		@type source_path: string
		@param destination_path: destination s3 path
		@type destination_path: string
		@return: None
		@rtype: None
		"""

		source_bucket, source_key = self._get_bucket_and_prefix(source_path)
		destination_bucket, destination_key = self._get_bucket_and_prefix(destination_path)
		copy_source = {
			'Bucket': source_bucket,
			'Key': source_key
		}
		self.s3_resource.meta.client.copy(copy_source, destination_bucket, destination_key)
		self.delete_file(source_path)

	def delete_file(self, path):
		"""
		to delete a file from s3
		@param path: s3 path
		@type path: string
		@return: None
		@rtype: None
		"""
		bucket_name, key = self._get_bucket_and_prefix(path)
		self.s3_resource.Object(bucket_name, key).delete()

	def get_files_in_s3_directory(self, path, filter_file=None):
		"""
		return files in an s3 directory
		@param path: s3 path
		@type path: string
		@param filter_file: filter text
		@type filter_file: string
		@return: list of file path
		@rtype: list
		"""
		bucket_name, key = self._get_bucket_and_prefix(path)

		# get all the files using list_objects_v2, pagination limit of 1000 is handled
		response = self.s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key)
		files = [i['Key'] for i in response['Contents']]
		while 'NextContinuationToken' in response:
			response = self.s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key,
			                                          ContinuationToken=response['NextContinuationToken'])
		files.extend([i['Key'] for i in response['Contents']])
		if filter_file:
			files = [_file for _file in files if filter_file in _file]
		return files